package com.example.dataModel;

public class SearchModel {

	public String searchIds;

	/**
	 * @return the searchIds
	 */
	public String getSearchIds() {
		return searchIds;
	}

	/**
	 * @param searchIds the searchIds to set
	 */
	public void setSearchIds(String searchIds) {
		this.searchIds = searchIds;
	}
	
	
}
