package com.example.dataModel;

public class LoginModel {
	String mUsername, mPassword;
	public String mUserId;
	/**
	 * @return the mUserId
	 */
	public String getmUserId() {
		return mUserId;
	}

	/**
	 * @param mUserId the mUserId to set
	 */
	public void setmUserId(String mUserId) {
		this.mUserId = mUserId;
	}

	public String getmUsername() {
		return mUsername;
	}

	public void setmUsername(String mUsername) {
		this.mUsername = mUsername;
	}

	public String getmPassword() {
		return mPassword;
	}

	public void setmPassword(String mPassword) {
		this.mPassword = mPassword;
	}


}
