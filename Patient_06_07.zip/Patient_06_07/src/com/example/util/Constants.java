package com.example.util;

public class Constants {

	public static String SERVER_URL = "http://192.168.1.3:8081/Doctor";

}
